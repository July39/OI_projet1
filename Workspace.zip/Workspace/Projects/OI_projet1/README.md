Début d'un grand projet
Écrivons ici les notes pour l'équipe
Pas encore terminer l'interface mais une bonne partie est fait!
