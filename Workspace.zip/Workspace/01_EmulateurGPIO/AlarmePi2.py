'''
Created on 21 juin 2021

@author: gills
'''
from enum import Enum
from RPiSim import GPIO
from threading import Thread
from Ecran import Ecran
import sys
import signal
import time
import pygame

PORTE_PIN = 5
SIRENE_PIN = 18

CODE_SECRET = "1234"
   
class Etat(Enum):
    OFF = 1
    DELAI_E = 2
    ARME = 3
    DELAI_S = 4
    SIRENE = 5

etat = Etat.OFF

class Event(Enum):
    porte = 1
    btnArm = 2
    code = 3
    boutonInterface = 4
    finDelais = 5

###############################################
""" Les fonctions """
###############################################
    
def terminer(signum, frame):
    print("Terminer")
    GPIO.output(SIRENE_PIN, GPIO.LOW)
    GPIO.cleanup()
    pygame.quit()
    sys.exit(0)

def event_porte(channel):
    print("event porte")
    setEtat(Event.porte)

def setEtat(event):
    global etat
    global thread
    print("set etat")
    if event == Event.btnArm:
        if etat == Etat.OFF:
            print ("Delais de sortie")
            etat = Etat.DELAI_S
            thread = Thread(target=blinkDEL, args=())
            thread.start()
        elif etat == Etat.ARME:
            print ("Desarmer")
            etat = Etat.OFF
            GPIO.output(SIRENE_PIN, GPIO.LOW)
        elif etat == Etat.DELAI_S:
            print ("Desarmer")
            etat = Etat.OFF
            #thread.stop()
        elif etat == Etat.SIRENE:
            print ("Desarmer")
            etat = Etat.OFF
            GPIO.output(SIRENE_PIN, GPIO.LOW) 
        elif etat == Etat.DELAI_E:
            print ("Desarmer")
            etat = Etat.OFF
            #thread.stop()           
    elif event == Event.finDelais:
        if etat == Etat.DELAI_S:
            print ("Armer")
            etat = Etat.ARME
        elif etat == Etat.DELAI_E:
            print("Sirene")
            etat = Etat.SIRENE
            GPIO.output(SIRENE_PIN, GPIO.HIGH)
    elif event == Event.porte:
        if etat == Etat.ARME:
            print("Ouverture d'une porte")
            etat = Etat.DELAI_E
            thread = Thread(target=blinkDEL, args=())
            thread.start()
              

def blinkDEL():
    global DELAI_AFF
    DELAI = 6
    delai = 0
    while delai <= DELAI:
        if etat == Etat.OFF:
            return
        DELAI_AFF = str(DELAI - delai)
        time.sleep(1)
        delai = delai + 1
    setEtat(Event.finDelais)
            
###################################            
""" Mon programme """
###################################

""" Configuration des GPIOs """
signal.signal(signal.SIGINT, terminer)
try:
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    """ Porte """
    GPIO.setup(PORTE_PIN,GPIO.MODE_IN,pull_up_down = GPIO.PUD_UP) 
    GPIO.add_event_detect(PORTE_PIN, GPIO.FALLING, callback=event_porte)
    
    """ Sirene """
    GPIO.setup(SIRENE_PIN,GPIO.MODE_OUT, initial=GPIO.LOW)
    
except Exception:
    print("Problème avec les GPIO")

""" Mise en place de l'interface """
pygame.init()
screen = pygame.display.set_mode([480, 320])
ecran = Ecran(screen)
    
running = True
    
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            print("Clic bouton!")
            xSouris, ySouris = pygame.mouse.get_pos()
            if etat == Etat.OFF:
                if ecran.isOverArmBtn((xSouris,ySouris)):
                    print("Arm")
                    setEtat(Event.btnArm)
            else:
                ecran.readKeyPad((xSouris,ySouris))
                print(ecran.code)
                if ecran.code == CODE_SECRET:
                    ecran.code = ""          # Attention! encore des petits bug
                    ecran.codeEcran = ""
                    setEtat(Event.btnArm)
                            
            
    if etat == Etat.OFF:
        ecran.arm()
    elif etat == Etat.DELAI_S:
        ecran.disarm("Arming...   " + DELAI_AFF)
    elif etat == Etat.DELAI_E:
        ecran.disarm("Enter your code to disarm the System " + DELAI_AFF)
    else:
        ecran.disarm("Enter your code to disarm the System")
        
    pygame.display.flip()

pygame.quit()
GPIO.output(SIRENE_PIN, GPIO.LOW)
GPIO.cleanup()
sys.exit(0)
    
    
    