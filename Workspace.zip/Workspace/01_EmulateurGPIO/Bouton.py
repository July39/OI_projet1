'''
Created on 21 juin 2021

@author: gills
'''
import pygame

class Bouton():
    def __init__(self, couleur, x, y, largeur, hauteur, taillePolice, couleurPolice, texte=''):
        self.couleur = couleur
        self.x = x
        self.y = y
        self.largeur = largeur
        self.hauteur = hauteur
        self.taillePolice = taillePolice
        self.couleurPolice = couleurPolice
        self.texte = texte

    def dessiner(self, screen): 
        sysfont = pygame.font.get_default_font()
        font = pygame.font.SysFont(None, self.taillePolice)     
        pygame.draw.rect(screen, self.couleur, (self.x, self.y, self.largeur, self.hauteur), 0)
        txtBtn = font.render(self.texte, True, self.couleurPolice)
        rectBtn = txtBtn.get_rect()
        rectBtn.center = ( (self.x+(self.largeur/2)), (self.y+(self.hauteur/2)) )
        screen.blit(txtBtn, rectBtn)

    def isOverBouton(self, posSouris):
        xSouris = posSouris[0]
        ySouris = posSouris[1]
        
        absX = (xSouris-self.x)
        absY = (ySouris-self.y)
        if absX > 0 and absX < self.largeur and absY > 0 and absY < self.hauteur:
            return(True)
        return(False)

if __name__ == "__main__":
    print ("Début du test")
    pygame.init()

    # couleur
    NOIR = (0, 0, 0)
    ROUGE = (255, 0, 0)
    VERT = (69, 204, 23)
    BLEU = (0, 0, 255)
    BLEU_PALE = (24, 195, 245)
    BLEU_FONCE = (12, 74, 109)
    GRIS = (200, 200, 200)
    BLANC = (255, 255, 255)
    
    screen = pygame.display.set_mode([500, 500])
    
    btn = Bouton(GRIS, 250, 250, 200, 200, 36, BLANC, "ON/OFF")
    
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                xSouris,ySouris = pygame.mouse.get_pos()
                if btn.isOverBouton((xSouris,ySouris)):
                    print("Clic bouton!")
                
        screen.fill(BLANC)
    
        btn.dessiner(screen)
    
        pygame.display.flip()

    pygame.quit()
    print("Fin du test")
    