'''
Created on 22 juin 2021

@author: gills
'''
import pygame
import requests
from datetime import datetime
from Bouton import Bouton

# couleur
NOIR = (0, 0, 0)
ROUGE = (255, 0, 0)
VERT = (69, 204, 23)
BLEU = (0, 0, 255)
BLEU_PALE = (24, 195, 245)
BLEU_FONCE = (12, 74, 109)
GRIS = (200, 200, 200)
BLANC = (255, 255, 255)

class Ecran():
    def __init__(self, screen):
        self.screen = screen
        #sysfont = pygame.font.get_default_font()
        self.font_1 = pygame.font.SysFont(None, 24)
        self.font_2 = pygame.font.SysFont(None, 36)
        
        self.imgCadena = pygame.image.load("lock.png").convert_alpha()
        self.imgCadenaOpen = pygame.image.load("lock_open.png").convert_alpha()
        
        self.getMeteo()
        self.boutons = [Bouton(BLEU_FONCE, 240, 90, 70, 50, 36, BLANC, "1"),
                        Bouton(BLEU_FONCE, 323, 90, 70, 50, 36, BLANC, "2"),
                        Bouton(BLEU_FONCE, 405, 90, 70, 50, 36, BLANC, "3"),
                        Bouton(BLEU_FONCE, 240, 147, 70, 50, 36, BLANC, "4"),
                        Bouton(BLEU_FONCE, 323, 147, 70, 50, 36, BLANC, "5"),
                        Bouton(BLEU_FONCE, 405, 147, 70, 50, 36, BLANC, "6"),
                        Bouton(BLEU_FONCE, 240, 204, 70, 50, 36, BLANC, "7"),
                        Bouton(BLEU_FONCE, 323, 204, 70, 50, 36, BLANC, "8"),
                        Bouton(BLEU_FONCE, 405, 204, 70, 50, 36, BLANC, "9"),
                        Bouton(BLEU_FONCE, 240, 262, 70, 50, 36, BLANC, "X"),
                        Bouton(BLEU_FONCE, 323, 262, 70, 50, 36, BLANC, "0"),
                        Bouton(BLEU_FONCE, 405, 262, 70, 50, 36, BLANC, "<-")]
        
        self.code = ""
        self.codeEcran = ""
        
    def entete(self, texte):
        pygame.draw.rect(self.screen, BLEU_FONCE, (0, 0, 480, 40), 0)
        txtEntete = self.font_1.render(texte, True, BLANC)
        self.screen.blit(txtEntete, (20, 10))
        heure = datetime.now().strftime("%H:%M:%S")
        txtHeure = self.font_1.render(heure, True, BLANC)
        self.screen.blit(txtHeure, (400, 10))
        
    def arm(self):
        self.screen.fill(BLEU_PALE)
        self.entete("System Ready, Not Armed")
        
        pygame.draw.rect(self.screen, VERT, (280, 80, 160, 160), 0)
        img1 = self.font_1.render("ARM", True, BLANC)
        self.screen.blit(img1, (340, 210))
        self.screen.blit(self.imgCadena, (310, 100))
        
        imgMeteo = pygame.image.load("Icon3/" + self.meteoIcone + ".png").convert_alpha()
        self.screen.blit(imgMeteo, (60, 80))
        txtTemp = self.font_1.render(self.meteoTemp + chr(176) +"C", True, BLANC)
        self.screen.blit(txtTemp, (100, 200))
    
    def isOverArmBtn(self, posSouris):
        xSouris = posSouris[0]
        ySouris = posSouris[1]
        
        absX = (xSouris - 280)
        absY = (ySouris - 80)
        if absX > 0 and absX < 160 and absY > 0 and absY < 160:
            return(True)
        return(False)
    
    def disarm(self, msg):
        self.screen.fill(BLEU_PALE)
        self.entete(msg)
        
        pygame.draw.rect(self.screen, ROUGE, (50, 80, 160, 160), 0)
        img1 = self.font_1.render("DISARM", True, BLANC)
        self.screen.blit(img1, (97, 210))
        self.screen.blit(self.imgCadenaOpen, (83, 100))
    
        # Mot de passe
        pygame.draw.rect(self.screen, BLANC, (240, 45, 235, 40), 0)
        txtPasswd = self.font_2.render(self.codeEcran, True, NOIR)
        rectPasswd = txtPasswd.get_rect()
        rectPasswd.center = ( (240+(235/2)), (45+(40/2)) )
        self.screen.blit(txtPasswd, rectPasswd)
        
        for btn in self.boutons:
            btn.dessiner(self.screen)
    
    def readKeyPad(self, posSouris):
        for btn in self.boutons:
            if btn.isOverBouton(posSouris):
                if btn.texte == "X":
                    self.code = ""
                    self.codeEcran = ""
                elif btn.texte == "<-":
                    self.code = self.code[:-1]
                    self.codeEcran = self.codeEcran[:-1]
                else:
                    self.code = self.code + btn.texte
                    self.codeEcran = self.codeEcran + "*"
                    
        return self.code
    
    def getMeteo(self): # Peut-être faire une classe
        print("getMeteo")
        api_key = '568628788222f8da10914685f8dfbdac';
        url = 'http://api.openweathermap.org/data/2.5/weather?q=Montreal,ca&lang=fr&units=metric&appid=' + api_key;
        reponse = requests.get(url)
        data = reponse.json()
        self.meteoTemp = str(int(round(data['main']['temp'])))
        self.meteoIcone = data['weather'][0]['icon']
            
if __name__ == "__main__":
    print ("Début du test")
    pygame.init()
    
    screen = pygame.display.set_mode([480, 320])
    
    ecran = Ecran(screen)
    
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                xSouris, ySouris = pygame.mouse.get_pos()
                #print (ecran.isOverArmBtn((xSouris,ySouris)))
                print(ecran.readKeyPad((xSouris,ySouris)))
                print("Clic bouton!")
                
        """ """    
        #ecran.arm()
        ecran.disarm("Enter your code to disarm the System")
    
        pygame.display.flip()

    pygame.quit()
    print("Fin du test")
    