'''
Created on 8 juill. 2021

@author: gills

'''
import pymongo

client = pymongo.MongoClient("localhost")
db = client.projet1 # La base de donnée projet 1
print(db.name)
print(db.collection_names())


