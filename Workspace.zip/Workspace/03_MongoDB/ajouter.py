'''
Created on 8 juill. 2021

@author: gills
'''
import pymongo

client = pymongo.MongoClient("localhost")
db = client.demo                                # La base de donnée demo
collection = db.contacts
unContact = 	{
			"nom": "Gill",
        		"prenom" : "Stephane",
        		"telephone": "15143895921",
        		"email": "Stephane.Gill@CollegeAhuntsic.qc.ca"
        	}

print(collection.insert_one(unContact).inserted_id)
