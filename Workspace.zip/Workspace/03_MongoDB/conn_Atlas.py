'''
Created on 19 août 2021

@author: gills
'''
from pymongo import MongoClient

client = MongoClient("mongodb+srv://m001_student:admin@cluster0.5v451.mongodb.net/")

db = client.sample_airbnb
monListing = db.listingsAndReviews

print(monListing.find_one())
