'''
Created on 7 juill. 2021

@author: gills

Référence: 
 - http://www.steves-internet-guide.com/send-json-data-mqtt-python/
 - https://assetwolf.com/learn/how-to-send-json-data-over-mqtt
'''
import json

""" Decoder un message en JSON """
message_in = "{\"id\": 1234, \"cmd\": \"envoyerEtat\"}"
print (message_in, type(message_in))
data_in = json.loads(message_in)
print (data_in, type(data_in))
print (data_in['id'])

""" Encoder des données en JSON """
data_out = {}
data_out['id'] = 4321
data_out['cmd'] = "Armé"
print (data_out, type(data_out))
message_out = json.dumps(data_out)
print (message_out, type(message_out))



import json

class MsgProxy:

	# construct an object from a string - used in MQTT callback function
	__init__(self, str_msg: str):
		self.obj = json.loads(str_msg)
		
	# construct an object from arguments - used to publish
	__init__(self, topic: str, command: str):
		self.obj = {}
		self.obj['topic'] = topic
		self.obj['command'] = command
		
	__str__(self):
		return json.dumps(self.obj) 
		
		
		
		
		
	
	
