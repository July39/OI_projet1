'''
Created on 21 juin 2021

@author: https://medium.com/python-point/mqtt-basics-with-python-examples-7c758e605d4
'''
import paho.mqtt.client as mqtt 
from random import randrange, uniform
import time



#mqttBroker = "mqtt.eclipseprojects.io" 
mqttBroker = "127.0.0.1" 

client = mqtt.Client("Temperature_Interieur")
client.connect(mqttBroker) 

while True:
    randNumber = uniform(18.0, 24.0)
    client.publish("TEMPERATURE", randNumber)
    print("Just published " + str(randNumber) + " to topic TEMPERATURE")
    time.sleep(2)
