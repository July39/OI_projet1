'''
Created on 21 juin 2021

@author: https://medium.com/python-point/mqtt-basics-with-python-examples-7c758e605d4
'''
import paho.mqtt.client as mqtt
import time

def on_message(client, userdata, message):
    print("received message: " ,str(message.payload.decode("utf-8")))

host          = "node02.myqtthub.com"
port          = 1883
clean_session = True
client_id     = "MonTelephone"
user_name     = "phone"
password      = "xxxxx"

client = mqtt.Client(client_id = client_id, clean_session = clean_session)
client.username_pw_set (user_name, password)
client.connect (host, port)

client.loop_start()

client.subscribe("TEMPERATURE")
client.on_message=on_message 

time.sleep(30)
client.loop_stop()
print("Terminer")
