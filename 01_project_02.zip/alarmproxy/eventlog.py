
import pymongo
from datetime import date, datetime
from constants import *


# event log - used by the alarm proxy to log new events.
#             it is also used by the history window to
#             show last event logs
class EventLog:

    def __init__(self):

        # use the good mongo database
        client = pymongo.MongoClient(MONGODB_URI)
        self.db = client.project1

    def write_event(self, event):
        return(self.db.events.insert_one({
            "date":  date.today().strftime(DATE_FORMAT),
            "time":  datetime.now().strftime(TIME_FORMAT),
            "id": event['id'],
            "cmd": event['cmd'],
        }).inserted_id)

    def get_event_logs(self):
        return self.db.events.find().sort([
            ['date' ,-1],
            ['time', -1]]).limit(10)
