from abc import ABC, abstractmethod
import paho.mqtt.client as mqtt
import json
from constants import *
from eventlog import EventLog


# alarm listener - implemented by the main window to update widgets
class AlarmListener(ABC):

    @abstractmethod
    def on_alarm_on(self):
        pass

    @abstractmethod
    def on_alarm_off(self):
        pass

    @abstractmethod
    def on_alarm_ring(self):
        pass


#  alarm proxy - used by the main window to invoke alarm methods
class AlarmProxy:

    @staticmethod
    def on_message_static(client, userdata, message):

        # forward the call to non-static method - retreive self from userdata
        proxy: AlarmProxy = userdata
        proxy.on_message(client, message)

    def on_message(self, client, message):

        # unpack the event from the message
        msg = json.loads(str(message.payload.decode("utf-8")))
        if msg['id'] == CLIENT_SYSALARM:

            # write the event into the event log
            self.event_log.write_event(msg)

            # dispatch the event to the listener
            if msg['cmd'] == SYSALARM_STATE_OFF:
                self.listener.on_alarm_off()
            elif msg['cmd'] == SYSALARM_STATE_ON:
                self.listener.on_alarm_on()
            elif msg['cmd'] == SYSALARM_INTRUDER:
                self.listener.on_alarm_ring()

    def __init__(self, listener: AlarmListener) -> None:

        # init. MQTT - pass self as userdata
        self.client = mqtt.Client(client_id=CLIENT_CONSOLE, userdata=self)
        self.client.connect(MQTT_BROKER) 
        self.client.loop_start()
        self.client.subscribe(TOPIC_STATE)
        self.client.on_message = AlarmProxy.on_message_static

        # init. the listener
        self.listener: AlarmListener = listener

        # init. the log history
        self.event_log: EventLog = EventLog()

    def __del__(self):
        self.client.loop_stop()
        self.client.disconnect()

    def turn_on(self):
        msg = {'id': CLIENT_SYSALARM, 'cmd': SYSALARM_CMD_ON}
        self.client.publish(TOPIC_COMMAND, json.dumps(msg))

    def turn_off(self):
        msg = {'id': CLIENT_SYSALARM, 'cmd': SYSALARM_CMD_OFF}
        self.client.publish(TOPIC_COMMAND, json.dumps(msg))
