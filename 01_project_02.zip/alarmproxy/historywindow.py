from tkinter import *
from eventlog import EventLog


# history window
class HistoryWindow(Frame):

    # event handlers
    def on_destroy_window(self):
        self.master.destroy()

    # class constructor
    def __init__(self, master=None):

        # init. window
        super().__init__(master) 
        self.master = master
        self.master.title("History")
        self.master.geometry("300x225")
        self.master.protocol("WM_DELETE_WINDOW", lambda: self.on_destroy_window())
        self.pack()

        # create widgets
        self.txt = Text(self)
        self.txt.config(width=40, height=12)
        self.txt.grid(row=0, column=0, columnspan=3)

        # insert the last logs to the widget
        event_log: EventLog = EventLog()
        for event in event_log.get_event_logs():
            self.txt.insert(INSERT, f"{event['date']} \t {event['time']} \t {event['id']} \t {event['cmd']}\n")
        del event_log



