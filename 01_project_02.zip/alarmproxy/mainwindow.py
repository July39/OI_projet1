from historywindow import HistoryWindow
from tkinter import *
from alarmproxy import AlarmProxy, AlarmListener


# main window
class MainWindow(Frame, AlarmListener):

    # window command handlers
    def on_turn_alarm_on(self):
        self.alarm_proxy.turn_on()

    def on_turn_alarm_off(self):
        self.alarm_proxy.turn_off()

    def on_show_history(self):
        window = HistoryWindow(master=Tk())

    def on_destroy_window(self):
        del self.alarm_proxy
        self.master.destroy()

    # class constructor
    def __init__(self, master=None):

        # init. the window
        super().__init__(master)
        self.master = master
        self.master.protocol("WM_DELETE_WINDOW", lambda: self.on_destroy_window())
        self.pack()

        # create alarm widgets
        self.lbl_alarm = Label(self, text="Alarm")
        self.lbl_alarm.grid(row=0, column=0, columnspan=2)
        btn = Button(self, text="ON", command=self.on_turn_alarm_on)
        btn.grid(row=1, column=0)
        btn = Button(self, text="OFF", command=self.on_turn_alarm_off)
        btn.grid(row=1, column=1)

        # create history widgets
        lbl = Label(self, text="History")
        lbl.grid(row=8, column=0, columnspan=2)
        btn = Button(self, text="Show...", command=self.on_show_history)
        btn.grid(row=9, column=1)

        # create alarm proxy
        self.alarm_proxy = AlarmProxy(self)

    # alarm listener implementation
    def on_alarm_on(self):
        self.lbl_alarm.configure(text="Alarm: ON")
 
    def on_alarm_off(self):
        self.lbl_alarm.configure(text="Alarm: OFF")
 
    def on_alarm_ring(self):
        self.lbl_alarm.configure(text="Alarm: CALL 911 - ALARM!")

